/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo;
import java.sql.*;
import java.sql.Connection;
public class Connections {
    static Connection con;
    
    public static Connection getConnection(){
        try{
            Class.forName(("com.mysql.jdbc.Driver"));
            String url = "jdbc:mysql://localhost:3306/hoteldbfinal";
            String username = "root";
            String password = "";
            Connection con = DriverManager.getConnection(url, username, password);
        }catch(Exception ex){
            System.out.println(""+ex);
        }
        return con;
    }
}
