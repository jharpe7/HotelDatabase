/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo;

/**
 *
 * @author Jonathan
 */
public class Employee {
    private String ssn, fname, lname, e_username, e_password, address, telephone, e_type, super_ssn;
    private int shift;
    public Employee(String fname, String lname, String ssn, String address, String telephone, String e_username, String e_password, String e_type, int shift, String super_ssn){
        this.ssn = ssn;
        this.fname = fname;
        this.lname = lname;
        this.e_username = e_username;
        this.e_password = e_password;
        this.address = address;
        this.telephone = telephone;
        this.e_type = e_type;
        this.super_ssn = super_ssn;
        this.shift = shift;
    }

    public String getSsn() {
        return ssn;
    }

    public String getFname() {
        return fname;
    }

    public String getLname() {
        return lname;
    }

    public String getE_username() {
        return e_username;
    }

    public String getE_password() {
        return e_password;
    }

    public String getAddress() {
        return address;
    }

    public String getTelephone() {
        return telephone;
    }

    public String getE_type() {
        return e_type;
    }

    public String getSuper_ssn() {
        return super_ssn;
    }

    public int getShift() {
        return shift;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public void setE_username(String e_username) {
        this.e_username = e_username;
    }

    public void setE_password(String e_password) {
        this.e_password = e_password;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public void setE_type(String e_type) {
        this.e_type = e_type;
    }

    public void setSuper_ssn(String super_ssn) {
        this.super_ssn = super_ssn;
    }

    public void setShift(int shift) {
        this.shift = shift;
    }
    
    
}
