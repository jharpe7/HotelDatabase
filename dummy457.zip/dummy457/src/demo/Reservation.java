/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo;

/**
 *
 * @author jamiaharper
 */
class Reservation {
    private String res_num, r_Ssn, checkin, checkout,r_num,guest_uname;
    private boolean checkedIn, checkedOut;
    public Reservation(String res_num, String r_Ssn, String checkin, String checkout, String r_num, String guest_uname, boolean checkedIn, boolean checkoutOut){
        this.res_num = res_num;
        this.r_Ssn = r_Ssn;
        this.checkin = checkin;
        this.checkout = checkout;
        this.r_num = r_num;
        this.guest_uname = guest_uname;
        this.checkedIn = checkedIn;
        this.checkedOut  = checkedOut;
    }
    public String getResnum(){
        return res_num;
    }
    public String getSsn(){
        return r_Ssn;
    }
    public String getCheckinD(){
        return checkin;
    }
    public String getCheckout(){
        return checkout;
    }
    public String getRoom(){
        return r_num;
    }
    public String getGuest(){
        return guest_uname;
    }
    public boolean isCheckin(){
        return checkedIn;
    }
    public boolean isCheckout(){
        return checkedOut;
       
    }
}
